
/*
*    MCreator note: This file will be REGENERATED on each build.
*/
package net.mcreator.aaaaaaaaaaaaaaaaa.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.village.VillagerTradesEvent;
import net.minecraftforge.common.BasicItemListing;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.npc.VillagerTrades;
import net.minecraft.world.entity.npc.VillagerProfession;

import java.util.List;

import it.unimi.dsi.fastutil.ints.Int2ObjectMap;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.FORGE)
public class AaaaaaaaaaaaaaaaaModTrades {
	@SubscribeEvent
	public static void registerTrades(VillagerTradesEvent event) {
		Int2ObjectMap<List<VillagerTrades.ItemListing>> trades = event.getTrades();
		if (event.getType() == VillagerProfession.ARMORER) {
			trades.get(2).add(new BasicItemListing(new ItemStack(AaaaaaaaaaaaaaaaaModItems.RUBY.get(), 6), new ItemStack(Items.IRON_HELMET),
					new ItemStack(AaaaaaaaaaaaaaaaaModItems.RUBY_ARMOR_HELMET.get()), 10, 10, 0.05f));
			trades.get(2).add(new BasicItemListing(new ItemStack(AaaaaaaaaaaaaaaaaModItems.RUBY.get(), 6), new ItemStack(Items.IRON_CHESTPLATE),
					new ItemStack(AaaaaaaaaaaaaaaaaModItems.RUBY_ARMOR_CHESTPLATE.get()), 20, 10, 0.05f));
			trades.get(2).add(new BasicItemListing(new ItemStack(AaaaaaaaaaaaaaaaaModItems.RUBY.get(), 6), new ItemStack(Items.IRON_LEGGINGS),
					new ItemStack(AaaaaaaaaaaaaaaaaModItems.RUBY_ARMOR_LEGGINGS.get()), 20, 10, 0.05f));
			trades.get(2).add(new BasicItemListing(new ItemStack(AaaaaaaaaaaaaaaaaModItems.RUBY.get(), 6), new ItemStack(Items.IRON_BOOTS),
					new ItemStack(AaaaaaaaaaaaaaaaaModItems.RUBY_ARMOR_BOOTS.get()), 20, 10, 0.05f));
		}
		if (event.getType() == VillagerProfession.WEAPONSMITH) {
			trades.get(2).add(new BasicItemListing(new ItemStack(AaaaaaaaaaaaaaaaaModItems.RUBY.get(), 6), new ItemStack(Items.IRON_SWORD),
					new ItemStack(AaaaaaaaaaaaaaaaaModItems.RUBY_SWORD.get()), 20, 10, 0.05f));
			trades.get(2).add(new BasicItemListing(new ItemStack(AaaaaaaaaaaaaaaaaModItems.RUBY.get(), 6), new ItemStack(Items.IRON_AXE),
					new ItemStack(AaaaaaaaaaaaaaaaaModItems.RUBY_AXE.get()), 20, 10, 0.05f));
			trades.get(2).add(new BasicItemListing(new ItemStack(AaaaaaaaaaaaaaaaaModItems.RUBY.get(), 6), new ItemStack(Items.IRON_PICKAXE),
					new ItemStack(AaaaaaaaaaaaaaaaaModItems.RUBY_PICK_AXE.get()), 20, 10, 0.05f));
			trades.get(2).add(new BasicItemListing(new ItemStack(AaaaaaaaaaaaaaaaaModItems.RUBY.get(), 6), new ItemStack(Items.IRON_SHOVEL),
					new ItemStack(AaaaaaaaaaaaaaaaaModItems.RUBY_SHOVEL.get()), 20, 10, 0.05f));
			trades.get(2).add(new BasicItemListing(new ItemStack(AaaaaaaaaaaaaaaaaModItems.RUBY.get(), 6), new ItemStack(Items.IRON_HOE),
					new ItemStack(AaaaaaaaaaaaaaaaaModItems.RUBY_HOE.get()), 20, 10, 0.05f));
			trades.get(1).add(new BasicItemListing(new ItemStack(AaaaaaaaaaaaaaaaaModItems.RUBY_NUGGET.get(), 9),

					new ItemStack(AaaaaaaaaaaaaaaaaModItems.RUBY_INGOT.get()), 10, 5, 0.05f));
		}
	}
}
