
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.aaaaaaaaaaaaaaaaa.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.aaaaaaaaaaaaaaaaa.item.THISWILLNOTBEUSEDItem;
import net.mcreator.aaaaaaaaaaaaaaaaa.item.RubySwordItem;
import net.mcreator.aaaaaaaaaaaaaaaaa.item.RubyShovelItem;
import net.mcreator.aaaaaaaaaaaaaaaaa.item.RubyPickAxeItem;
import net.mcreator.aaaaaaaaaaaaaaaaa.item.RubyOGItem;
import net.mcreator.aaaaaaaaaaaaaaaaa.item.RubyNuggetItem;
import net.mcreator.aaaaaaaaaaaaaaaaa.item.RubyItem;
import net.mcreator.aaaaaaaaaaaaaaaaa.item.RubyIngotItem;
import net.mcreator.aaaaaaaaaaaaaaaaa.item.RubyHoeItem;
import net.mcreator.aaaaaaaaaaaaaaaaa.item.RubyAxeItem;
import net.mcreator.aaaaaaaaaaaaaaaaa.item.RubyARMORItem;
import net.mcreator.aaaaaaaaaaaaaaaaa.item.NetheritearmorItem;
import net.mcreator.aaaaaaaaaaaaaaaaa.item.NetheriteItem;
import net.mcreator.aaaaaaaaaaaaaaaaa.AaaaaaaaaaaaaaaaaMod;

public class AaaaaaaaaaaaaaaaaModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, AaaaaaaaaaaaaaaaaMod.MODID);
	public static final RegistryObject<Item> NETHERITE = REGISTRY.register("netherite", () -> new NetheriteItem());
	public static final RegistryObject<Item> NETERITE_BLOCK = block(AaaaaaaaaaaaaaaaaModBlocks.NETERITE_BLOCK,
			AaaaaaaaaaaaaaaaaModTabs.TAB_NETHERITE);
	public static final RegistryObject<Item> NETHERITEARMOR_HELMET = REGISTRY.register("netheritearmor_helmet",
			() -> new NetheritearmorItem.Helmet());
	public static final RegistryObject<Item> NETHERITEARMOR_CHESTPLATE = REGISTRY.register("netheritearmor_chestplate",
			() -> new NetheritearmorItem.Chestplate());
	public static final RegistryObject<Item> NETHERITEARMOR_LEGGINGS = REGISTRY.register("netheritearmor_leggings",
			() -> new NetheritearmorItem.Leggings());
	public static final RegistryObject<Item> NETHERITEARMOR_BOOTS = REGISTRY.register("netheritearmor_boots", () -> new NetheritearmorItem.Boots());
	public static final RegistryObject<Item> NETHERITE_ORE = block(AaaaaaaaaaaaaaaaaModBlocks.NETHERITE_ORE, AaaaaaaaaaaaaaaaaModTabs.TAB_NETHERITE);
	public static final RegistryObject<Item> RUBY_ARMOR_HELMET = REGISTRY.register("ruby_armor_helmet", () -> new RubyARMORItem.Helmet());
	public static final RegistryObject<Item> RUBY_ARMOR_CHESTPLATE = REGISTRY.register("ruby_armor_chestplate", () -> new RubyARMORItem.Chestplate());
	public static final RegistryObject<Item> RUBY_ARMOR_LEGGINGS = REGISTRY.register("ruby_armor_leggings", () -> new RubyARMORItem.Leggings());
	public static final RegistryObject<Item> RUBY_ARMOR_BOOTS = REGISTRY.register("ruby_armor_boots", () -> new RubyARMORItem.Boots());
	public static final RegistryObject<Item> THISWILLNOTBEUSED = REGISTRY.register("thiswillnotbeused", () -> new THISWILLNOTBEUSEDItem());
	public static final RegistryObject<Item> RUBY_BLOCK = block(AaaaaaaaaaaaaaaaaModBlocks.RUBY_BLOCK, AaaaaaaaaaaaaaaaaModTabs.TAB_NETHERITE);
	public static final RegistryObject<Item> RUBY_INGOT = REGISTRY.register("ruby_ingot", () -> new RubyIngotItem());
	public static final RegistryObject<Item> RUBY = REGISTRY.register("ruby", () -> new RubyItem());
	public static final RegistryObject<Item> RUBY_OG = REGISTRY.register("ruby_og", () -> new RubyOGItem());
	public static final RegistryObject<Item> RUBY_ORE = block(AaaaaaaaaaaaaaaaaModBlocks.RUBY_ORE, AaaaaaaaaaaaaaaaaModTabs.TAB_NETHERITE);
	public static final RegistryObject<Item> RUBY_AXE = REGISTRY.register("ruby_axe", () -> new RubyAxeItem());
	public static final RegistryObject<Item> RUBY_PICK_AXE = REGISTRY.register("ruby_pick_axe", () -> new RubyPickAxeItem());
	public static final RegistryObject<Item> RUBY_SWORD = REGISTRY.register("ruby_sword", () -> new RubySwordItem());
	public static final RegistryObject<Item> RUBY_SHOVEL = REGISTRY.register("ruby_shovel", () -> new RubyShovelItem());
	public static final RegistryObject<Item> RUBY_HOE = REGISTRY.register("ruby_hoe", () -> new RubyHoeItem());
	public static final RegistryObject<Item> RUBY_NUGGET = REGISTRY.register("ruby_nugget", () -> new RubyNuggetItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
