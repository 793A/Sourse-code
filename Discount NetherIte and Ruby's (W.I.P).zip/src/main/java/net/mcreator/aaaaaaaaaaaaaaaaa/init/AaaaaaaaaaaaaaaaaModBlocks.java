
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.aaaaaaaaaaaaaaaaa.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.aaaaaaaaaaaaaaaaa.block.RubyOREBlock;
import net.mcreator.aaaaaaaaaaaaaaaaa.block.RubyBlockBlock;
import net.mcreator.aaaaaaaaaaaaaaaaa.block.NetheriteOreBlock;
import net.mcreator.aaaaaaaaaaaaaaaaa.block.NeteriteBlockBlock;
import net.mcreator.aaaaaaaaaaaaaaaaa.AaaaaaaaaaaaaaaaaMod;

public class AaaaaaaaaaaaaaaaaModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, AaaaaaaaaaaaaaaaaMod.MODID);
	public static final RegistryObject<Block> NETERITE_BLOCK = REGISTRY.register("neterite_block", () -> new NeteriteBlockBlock());
	public static final RegistryObject<Block> NETHERITE_ORE = REGISTRY.register("netherite_ore", () -> new NetheriteOreBlock());
	public static final RegistryObject<Block> RUBY_BLOCK = REGISTRY.register("ruby_block", () -> new RubyBlockBlock());
	public static final RegistryObject<Block> RUBY_ORE = REGISTRY.register("ruby_ore", () -> new RubyOREBlock());
}
