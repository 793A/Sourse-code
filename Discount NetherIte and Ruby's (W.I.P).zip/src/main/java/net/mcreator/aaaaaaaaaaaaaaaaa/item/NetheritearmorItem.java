
package net.mcreator.aaaaaaaaaaaaaaaaa.item;

import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Entity;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.aaaaaaaaaaaaaaaaa.init.AaaaaaaaaaaaaaaaaModTabs;
import net.mcreator.aaaaaaaaaaaaaaaaa.init.AaaaaaaaaaaaaaaaaModItems;

public abstract class NetheritearmorItem extends ArmorItem {
	public NetheritearmorItem(EquipmentSlot slot, Item.Properties properties) {
		super(new ArmorMaterial() {
			@Override
			public int getDurabilityForSlot(EquipmentSlot slot) {
				return new int[]{13, 15, 16, 11}[slot.getIndex()] * 25;
			}

			@Override
			public int getDefenseForSlot(EquipmentSlot slot) {
				return new int[]{2, 5, 6, 2}[slot.getIndex()];
			}

			@Override
			public int getEnchantmentValue() {
				return 9;
			}

			@Override
			public SoundEvent getEquipSound() {
				return ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation(""));
			}

			@Override
			public Ingredient getRepairIngredient() {
				return Ingredient.of(new ItemStack(AaaaaaaaaaaaaaaaaModItems.NETHERITE.get()));
			}

			@Override
			public String getName() {
				return "netheritearmor";
			}

			@Override
			public float getToughness() {
				return 10f;
			}

			@Override
			public float getKnockbackResistance() {
				return 0.2f;
			}
		}, slot, properties);
	}

	public static class Helmet extends NetheritearmorItem {
		public Helmet() {
			super(EquipmentSlot.HEAD, new Item.Properties().tab(AaaaaaaaaaaaaaaaaModTabs.TAB_NETHERITE));
		}

		@Override
		public String getArmorTexture(ItemStack stack, Entity entity, EquipmentSlot slot, String type) {
			return "aaaaaaaaaaaaaaaaa:textures/models/armor/discount_netherite__layer_1.png";
		}
	}

	public static class Chestplate extends NetheritearmorItem {
		public Chestplate() {
			super(EquipmentSlot.CHEST, new Item.Properties().tab(AaaaaaaaaaaaaaaaaModTabs.TAB_NETHERITE));
		}

		@Override
		public String getArmorTexture(ItemStack stack, Entity entity, EquipmentSlot slot, String type) {
			return "aaaaaaaaaaaaaaaaa:textures/models/armor/discount_netherite__layer_1.png";
		}
	}

	public static class Leggings extends NetheritearmorItem {
		public Leggings() {
			super(EquipmentSlot.LEGS, new Item.Properties().tab(AaaaaaaaaaaaaaaaaModTabs.TAB_NETHERITE));
		}

		@Override
		public String getArmorTexture(ItemStack stack, Entity entity, EquipmentSlot slot, String type) {
			return "aaaaaaaaaaaaaaaaa:textures/models/armor/discount_netherite__layer_2.png";
		}
	}

	public static class Boots extends NetheritearmorItem {
		public Boots() {
			super(EquipmentSlot.FEET, new Item.Properties().tab(AaaaaaaaaaaaaaaaaModTabs.TAB_NETHERITE));
		}

		@Override
		public String getArmorTexture(ItemStack stack, Entity entity, EquipmentSlot slot, String type) {
			return "aaaaaaaaaaaaaaaaa:textures/models/armor/discount_netherite__layer_1.png";
		}
	}
}
