
package net.mcreator.aaaaaaaaaaaaaaaaa.item;

import net.minecraft.world.item.UseAnim;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

import net.mcreator.aaaaaaaaaaaaaaaaa.init.AaaaaaaaaaaaaaaaaModTabs;

public class RubyOGItem extends Item {
	public RubyOGItem() {
		super(new Item.Properties().tab(AaaaaaaaaaaaaaaaaModTabs.TAB_NETHERITE).stacksTo(64).rarity(Rarity.EPIC));
	}

	@Override
	public UseAnim getUseAnimation(ItemStack itemstack) {
		return UseAnim.EAT;
	}

	@Override
	public int getUseDuration(ItemStack itemstack) {
		return 0;
	}
}
