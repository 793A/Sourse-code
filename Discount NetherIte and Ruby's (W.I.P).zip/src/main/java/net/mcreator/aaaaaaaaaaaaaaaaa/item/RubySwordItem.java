
package net.mcreator.aaaaaaaaaaaaaaaaa.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

import net.mcreator.aaaaaaaaaaaaaaaaa.init.AaaaaaaaaaaaaaaaaModTabs;

public class RubySwordItem extends Item {
	public RubySwordItem() {
		super(new Item.Properties().tab(AaaaaaaaaaaaaaaaaModTabs.TAB_NETHERITE).durability(33).rarity(Rarity.EPIC));
	}

	@Override
	public int getEnchantmentValue() {
		return 26;
	}

	@Override
	public int getUseDuration(ItemStack itemstack) {
		return 0;
	}
}
